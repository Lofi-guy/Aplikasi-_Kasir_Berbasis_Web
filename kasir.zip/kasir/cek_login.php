<?php
session_start();
include "config/koneksi.php";

if (!isset($_POST['username'], $_POST['password'])) {
    header("Location: index.php?pesan=gagal");
    exit();
}

$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = md5(mysqli_real_escape_string($koneksi, $_POST['password']));


// Gunakan password hashing jika memungkinkan
$query = "SELECT * FROM tb_user WHERE username='$username' AND password='$password'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if ($data) {
    $_SESSION['UserID'] = $data['UserID']; // Tambahkan baris ini
    $_SESSION['username'] = $data['username'];
    $_SESSION['role'] = $data['role'];
    header("Location: admin/index.php");
    exit();
}
 else {
    header("Location: index.php?pesan=gagal");
    exit();
}
