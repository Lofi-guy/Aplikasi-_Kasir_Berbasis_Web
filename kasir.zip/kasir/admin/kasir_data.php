<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php"; // Tambahkan koneksi database

// Cek apakah ada notifikasi di SESSION
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];
    $notif_type = $_SESSION['notif_type'];

    echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Notifikasi',
                    text: '$notif',
                    icon: '$notif_type',
                    confirmButtonText: 'OK'
                });
            }, 500);
          </script>";

    unset($_SESSION['notif']);
    unset($_SESSION['notif_type']);
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Data Petugas<small>Aplikasi Kasir Madura</small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Petugas</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-user">
                    <i class="glyphicon glyphicon-plus"></i> Tambah
                </button>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <th>NO</th>
                        <th>NAMA PETUGAS</th>
                        <th>USERNAME</th>
                        <th>ROLE / AKSES</th>
                        <th>OPSI</th>
                    </thead>
                    <tbody>
                        <?php
                        $dt_user = mysqli_query($koneksi, "SELECT * FROM tb_user");
                        $no = 1;
                        while ($user = mysqli_fetch_array($dt_user)) {
                        ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($user['NamaUser']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td>
                                    <button type="button" class="btn btn-xs btn-warning" title="Edit" data-toggle="modal" data-target="#edit_user_<?php echo $user['UserID']; ?>">
                                        <i class="glyphicon glyphicon-edit"></i>
                                    </button>
                                    <button class="btn btn-xs btn-danger" title="Hapus"
                                        onclick="hapusPetugas(<?php echo $user['UserID']; ?>, '<?php echo htmlspecialchars($user['NamaUser']); ?>')">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal Edit -->
                            <div class="modal fade" id="edit_user_<?php echo $user['UserID']; ?>" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Edit Data Petugas</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="kasir_proses.php" method="POST">
                                                <input type="hidden" name="id_user" value="<?php echo $user['UserID']; ?>">
                                                <div class="form-group">
                                                    <label>Nama Petugas</label>
                                                    <input type="text" class="form-control" name="nm_user" value="<?php echo htmlspecialchars($user['NamaUser']); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Username</label>
                                                    <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Password (Kosongkan jika tidak ingin mengubah)</label>
                                                    <input type="password" class="form-control" name="password">
                                                </div>
                                                <div class="form-group">
                                                    <label>Role</label>
                                                    <select name="role" class="form-control">
                                                        <option value="Admin" <?php echo ($user['role'] == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                                                        <option value="Petugas" <?php echo ($user['role'] == 'Petugas') ? 'selected' : ''; ?>>Petugas</option>
                                                    </select>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary" name="update">Simpan</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="tambah-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Tambah Data Petugas</h4>
            </div>
            <div class="modal-body">
                <form action="kasir_proses.php" method="POST">
                    <div class="form-group">
                        <label>Nama Petugas</label>
                        <input type="text" class="form-control" name="nm_user" placeholder="Masukkan nama petugas" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" name="username" placeholder="Masukkan username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Masukkan password" required>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role" class="form-control">
                            <option value="Admin">Admin</option>
                            <option value="Petugas">Petugas</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="tambah">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
