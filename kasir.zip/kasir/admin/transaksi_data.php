<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php"; // Tambahkan koneksi database

// Cek apakah ada notifikasi di SESSION
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];  // Isi pesan notifikasi
    $notif_type = $_SESSION['notif_type'];  // Jenis notifikasi (success, warning, error)
    
    echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Notifikasi',
                    text: '$notif',
                    icon: '$notif_type',
                    confirmButtonText: 'OK'
                });
            }, 500);
          </script>";
    
    unset($_SESSION['notif']); // Hapus notifikasi setelah ditampilkan
    unset($_SESSION['notif_type']);
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Data Transaksi<small>Aplikasi Kasir Madura</small></h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Transaksi</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
                <a href="transaksi_tambah.php" class="btn btn-primary">
                    <i class="glyphicon glyphicon-plus"></i> Tambah</a>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>TANGGAL PENJUALAN</th>
                            <th>NAMA PELANGGAN</th>
                            <th>KASIR</th>
                            <th>TOTAL HARGA</th>
                            <th>OPSI</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT tb_penjualan.*, tb_pelanggan.NamaPelanggan, tb_user.NamaUser 
                              FROM tb_penjualan
                              INNER JOIN tb_pelanggan ON tb_pelanggan.PelangganID = tb_penjualan.PelangganID
                              INNER JOIN tb_user ON tb_user.UserID = tb_penjualan.UserID";
                    $dt_penjualan = mysqli_query($koneksi, $query);
                    if (!$dt_penjualan) {
                        echo "<tr><td colspan='6'>Terjadi kesalahan: " . mysqli_error($koneksi) . "</td></tr>";
                    } else {
                        $no = 1;
                        while ($transaksi = mysqli_fetch_array($dt_penjualan)) {
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($transaksi['TanggalPenjualan']) ?></td>
                                <td><?= htmlspecialchars($transaksi['NamaPelanggan']) ?></td>
                                <td><?= htmlspecialchars($transaksi['NamaUser']) ?></td>
                                <td>Rp <?= number_format($transaksi['TotalHarga'], 0, ',', '.') ?>,-</td>
                                <td><a href="transaksi_invoice_cetak.php?id=<?= $transaksi['PenjualanID'] ?>" class="btn btn-success">Cetak</a></td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    </tbody>

                </table>
            </div>
        </div>
    </section>
</div>

<?php include "footer.php"; ?>
