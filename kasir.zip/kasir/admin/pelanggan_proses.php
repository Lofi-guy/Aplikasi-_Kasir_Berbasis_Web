<?php
include "../config/koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id_pelanggan'])) { // Jika ada ID, berarti update data
        $PelangganID = $_POST[''];
        $nama = $_POST['nm_pelanggan'];
        $alamat = $_POST['alamat'];
        $no_hp = $_POST['no_hp'];

        // Cek data lama
        $cek = mysqli_query($koneksi, "SELECT * FROM tb_pelanggan WHERE PelangganID='$id_pelanggan'");
        $data = mysqli_fetch_assoc($cek);

        if ($data['NamaPelanggan'] == $nama && $data['Alamat'] == $alamat && $data['NomorTelepon'] == $no_hp) {
            $_SESSION['notif'] = "Data tidak mengalami perubahan.";
            $_SESSION['notif_type'] = "info";
        } else {
            $query = "UPDATE tb_pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NomorTelepon='$no_hp' WHERE PelangganID='$id_pelanggan'";
            if (mysqli_query($koneksi, $query)) {
                $_SESSION['notif'] = "Data berhasil diperbarui.";
                $_SESSION['notif_type'] = "success";
            } else {
                $_SESSION['notif'] = "Gagal memperbarui data.";
                $_SESSION['notif_type'] = "error";
            }
        }
    } else { // Jika tidak ada ID, berarti tambah data baru
        $nama = $_POST['nm_pelanggan'];
        $alamat = $_POST['alamat'];
        $no_hp = $_POST['no_hp'];

        $query = "INSERT INTO tb_pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$no_hp')";
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['notif'] = "Data pelanggan berhasil ditambahkan.";
            $_SESSION['notif_type'] = "success";
        } else {
            $_SESSION['notif'] = "Gagal menambahkan data.";
            $_SESSION['notif_type'] = "error";
        }
    }

    header("Location: pelanggan_data.php");
    exit();
}
?>
