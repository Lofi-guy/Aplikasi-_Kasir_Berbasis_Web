<?php
session_start();
include "../config/koneksi.php"; // Koneksi ke database

// Pastikan ada parameter DetailID yang dikirim melalui GET
if (isset($_GET['DetailID'])) {
    $DetailID = intval($_GET['DetailID']); // Pastikan nilai sebagai integer

    // Query hapus data
    $query = "DELETE FROM tb_detail_penjualan WHERE DetailID = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "i", $DetailID); // Bind nilai sebagai integer

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['notif'] = "Data berhasil dihapus.";
        $_SESSION['notif_type'] = "success";
    } else {
        $_SESSION['notif'] = "Gagal menghapus data: " . mysqli_error($koneksi); // Tampilkan error
        $_SESSION['notif_type'] = "error";
    }

    mysqli_stmt_close($stmt);
}

// Redirect kembali ke halaman transaksi_tambah.php
header("Location: transaksi_tambah.php");
exit();
?>
