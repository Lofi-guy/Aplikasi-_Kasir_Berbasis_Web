<?php
session_start();
include "../config/koneksi.php";

if (isset($_GET['PelangganID'])) {
    $PelangganID = $_GET['PelangganID'];

    // Eksekusi query hapus
    $hapus = mysqli_query($koneksi, "DELETE FROM tb_pelanggan WHERE PelangganID = '$PelangganID'");

    if ($hapus) {
        $_SESSION['notif'] = "Data pelanggan berhasil dihapus.";
        $_SESSION['notif_type'] = "success";
    } else {
        $_SESSION['notif'] = "Gagal menghapus data pelanggan.";
        $_SESSION['notif_type'] = "error";
    }
}

// Redirect kembali ke halaman pelanggan_data.php
header("location: pelanggan_data.php");
exit();
?>
