<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php"; // Tambahkan koneksi database

// Cek apakah ada notifikasi di SESSION
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];  // Isi pesan notifikasi
    $notif_type = $_SESSION['notif_type'];  // Jenis notifikasi (success, warning, error)
    
    echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Notifikasi',
                    text: '$notif',
                    icon: '$notif_type',
                    confirmButtonText: 'OK'
                });
            }, 500);
          </script>";
    
    unset($_SESSION['notif']); // Hapus notifikasi setelah ditampilkan
    unset($_SESSION['notif_type']);
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Data Produk<small>Aplikasi Kasir Madura</small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Produk</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-produk">
                    <i class="glyphicon glyphicon-plus"></i> Tambah
                </button>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <th>NO</th>
                        <th>NAMA PRODUK</th>
                        <th>HARGA</th>
                        <th>STOK</th>
                        <th>OPSI</th>
                    </thead>
                    <tbody>
                        <?php
                        $dt_produk = mysqli_query($koneksi, "SELECT * FROM tb_produk");
                        $no = 1;
                        while ($produk = mysqli_fetch_array($dt_produk)) {
                        ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo $produk['NamaProduk']; ?></td>
                                <td><?php echo "Rp", $produk['Harga']; ?></td>
                                <td><?php echo $produk['Stok']; ?></td>
                                <td>
                                    <!-- Tombol Edit -->
                                    <button type="button" class="btn btn-xs btn-warning" title="Edit" data-toggle="modal" data-target="#edit_produk_<?php echo $produk['ProdukID']; ?>">
                                        <i class="glyphicon glyphicon-edit"></i>
                                    </button>

                                    <!-- Tombol Hapus -->
                                    <button class="btn btn-xs btn-danger" title="Hapus"
                                        onclick="hapusproduk(<?php echo $produk['ProdukID']; ?>, '<?php echo $produk['NamaProduk']; ?>')">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal Edit Produk -->
                            <div class="modal fade" id="edit_produk_<?php echo $produk['ProdukID']; ?>" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Edit Data Produk</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="produk_proses.php" method="POST">
                                                <input type="hidden" name="id_produk" value="<?php echo $produk['ProdukID']; ?>">
                                                <div class="form-group">
                                                    <label>Nama Produk</label>
                                                    <input type="text" class="form-control" name="nm_produk" value="<?php echo $produk['NamaProduk']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Harga</label>
                                                    <input type="text" class="form-control" name="harga" value="<?php echo $produk['Harga']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Stok</label>
                                                    <input type="number" class="form-control" name="stok" value="<?php echo $produk['Stok']; ?>" required>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary" name="update">Simpan</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<!-- Modal Tambah Produk -->
<div class="modal fade" id="tambah-produk">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Tambah Data Produk</h4>
            </div>
            <div class="modal-body">
                <form action="produk_proses.php" method="POST">
                    <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" class="form-control" name="nm_produk" placeholder="Masukan Nama Produk" required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="text" class="form-control" name="harga" placeholder="Masukan Harga" required>
                    </div>
                    <div class="form-group">
                        <label>Stok</label>
                        <input type="number" class="form-control" name="stok" placeholder="Masukan Jumlah Stok" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>

<!-- Tambahkan jQuery dan Bootstrap jika belum ada di footer -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
