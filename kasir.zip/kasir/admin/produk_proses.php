<?php
include "../config/koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['id_produk'])) { // Jika ada ID, berarti update data
        $ProdukID = $_POST['id_produk']; // Perbaikan variabel
        $produk = $_POST['nm_produk'];
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];

        // Cek data lama
        $cek = mysqli_query($koneksi, "SELECT * FROM tb_produk WHERE ProdukID='$ProdukID'");
        $data = mysqli_fetch_assoc($cek);

        if ($data && $data['NamaProduk'] == $produk && $data['Harga'] == $harga && $data['Stok'] == $stok) {
            $_SESSION['notif'] = "Data tidak mengalami perubahan.";
            $_SESSION['notif_type'] = "info";
        } else {
            $query = "UPDATE tb_produk SET NamaProduk='$produk', Harga='$harga', Stok='$stok' WHERE ProdukID='$ProdukID'";
            if (mysqli_query($koneksi, $query)) {
                $_SESSION['notif'] = "Data berhasil diperbarui.";
                $_SESSION['notif_type'] = "success";
            } else {
                $_SESSION['notif'] = "Gagal memperbarui data.";
                $_SESSION['notif_type'] = "error";
            }
        }
    } else { // Jika tidak ada ID, berarti tambah data baru
        $produk = $_POST['nm_produk'];
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];

        $query = "INSERT INTO tb_produk (NamaProduk, Harga, Stok) VALUES ('$produk', '$harga', '$stok')";
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['notif'] = "Data produk berhasil ditambahkan.";
            $_SESSION['notif_type'] = "success";
        } else {
            $_SESSION['notif'] = "Gagal menambahkan data.";
            $_SESSION['notif_type'] = "error";
        }
    }

    header("Location: produk_data.php");
    exit();
}
?>
