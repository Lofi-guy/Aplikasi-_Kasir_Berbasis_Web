<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php"; // Tambahkan koneksi database

// Cek apakah ada notifikasi di SESSION
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];  // Isi pesan notifikasi
    $notif_type = $_SESSION['notif_type'];  // Jenis notifikasi (success, warning, error)
    
    echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Notifikasi',
                    text: '$notif',
                    icon: '$notif_type',
                    confirmButtonText: 'OK'
                });
            }, 500);
          </script>";
    
    unset($_SESSION['notif']); // Hapus notifikasi setelah ditampilkan
    unset($_SESSION['notif_type']);
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Data Pelanggan<small>Aplikasi Kasir Madura</small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Pelanggan</li>
        </ol>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-transaksi">

                    <i class="glyphicon glyphicon-plus"></i> Tambah
                </button>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <th>NO</th>
                        <th>NAMA PELANGGAN</th>
                        <th>ALAMAT</th>
                        <th>NO HP</th>
                        <th>OPSI</th>
                    </thead>
                    <tbody>
                        <?php
                        $dt_pelanggan = mysqli_query($koneksi, "SELECT * FROM tb_pelanggan");
                        $no = 1;
                        while ($pelanggan = mysqli_fetch_array($dt_pelanggan)) {
                        ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo $pelanggan['NamaPelanggan']; ?></td>
                                <td><?php echo $pelanggan['Alamat']; ?></td>
                                <td><?php echo $pelanggan['NomorTelepon']; ?></td>
                                <td>
                                    <button type="button" class="btn btn-xs btn-warning" title="Edit" data-toggle="modal" data-target="#edit_pelanggan_<?php echo $pelanggan['PelangganID']; ?>">
                                        <i class="glyphicon glyphicon-edit"></i>
                                    </button>
                                    <button class="btn btn-xs btn-danger" title="Hapus"
                                        onclick="hapusPelanggan(<?php echo $pelanggan['PelangganID']; ?>, '<?php echo $pelanggan['NamaPelanggan']; ?>')">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <div class="modal fade" id="edit_pelanggan_<?php echo $pelanggan['PelangganID']; ?>" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Edit Data Pelanggan</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="pelanggan_proses.php" method="POST">
                                                <input type="hidden" name="id_pelanggan" value="<?php echo $pelanggan['PelangganID']; ?>">
                                                <div class="form-group">
                                                    <label>Nama Pelanggan</label>
                                                    <input type="text" class="form-control" name="nm_pelanggan" value="<?php echo $pelanggan['NamaPelanggan']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Alamat</label>
                                                    <input type="text" class="form-control" name="alamat" value="<?php echo $pelanggan['Alamat']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Nomor Telepon</label>
                                                    <input type="number" class="form-control" name="no_hp" value="<?php echo $pelanggan['NomorTelepon']; ?>" required>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary" name="update">Simpan</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<div class="modal fade" id="tambah-transaksi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Tambah Data Pelanggan</h4>
            </div>
            <div class="modal-body">
                <form action="pelanggan_proses.php" method="POST">
                    <div class="form-group">
                        <label>Nama Pelanggan</label>
                        <input type="text" class="form-control" name="nm_pelanggan" placeholder="Enter nama pelanggan" required>
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="alamat" placeholder="Enter alamat" required>
                    </div>
                    <div class="form-group">
                        <label>Nomor Telepon</label>
                        <input type="number" class="form-control" name="no_hp" placeholder="Enter nomor telepon" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
