<?php
session_start();
include "../config/koneksi.php";

$no_trans = $_POST['no_trans'];
$produk_id = $_POST['produk'];
$jumlah = $_POST['jumlah'];

// Cek apakah transaksi utama sudah ada di tb_penjualan


// Ambil harga produk untuk menghitung subtotal
$dt_produk = mysqli_query($koneksi, "SELECT Harga FROM tb_produk WHERE ProdukID = '$produk_id'");
$produk = mysqli_fetch_array($dt_produk);
$harga = $produk['Harga'];
$subtotal = $harga * $jumlah;

// Masukkan ke tb_detail_penjualan
$query_detail = "INSERT INTO tb_detail_penjualan (PenjualanID, ProdukID, JumlahProduk, SubTotal) 
                 VALUES ('$no_trans', '$produk_id', '$jumlah', '$subtotal')";

if (mysqli_query($koneksi, $query_detail)) {
    $_SESSION['notif'] = "Barang berhasil ditambahkan ke transaksi!";
    $_SESSION['notif_type'] = "success";
} else {
    $_SESSION['notif'] = "Gagal menambahkan barang: " . mysqli_error($koneksi);
    $_SESSION['notif_type'] = "error";
}

header("Location: transaksi_tambah.php");
?>
