<?php
include "../config/koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['id_user'])) { // Jika ada ID, berarti update data
        $UserID = $_POST['id_user'];
        $nama = $_POST['nm_user'];
        $username = $_POST['username'];
        $role = $_POST['role'];
        $password = $_POST['password'];

        // Cek data lama
        $cek = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE UserID='$UserID'");
        $data = mysqli_fetch_assoc($cek);

        if ($data) {
            $password_query = "";
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $password_query = ", password='$hashed_password'";
            }

            if ($data['NamaUser'] == $nama && $data['username'] == $username && $data['role'] == $role && empty($password_query)) {
                $_SESSION['notif'] = "Data tidak mengalami perubahan.";
                $_SESSION['notif_type'] = "info";
            } else {
                $query = "UPDATE tb_user SET NamaUser='$nama', username='$username', role='$role' $password_query WHERE UserID='$UserID'";
                if (mysqli_query($koneksi, $query)) {
                    $_SESSION['notif'] = "Data berhasil diperbarui.";
                    $_SESSION['notif_type'] = "success";
                } else {
                    $_SESSION['notif'] = "Gagal memperbarui data.";
                    $_SESSION['notif_type'] = "error";
                }
            }
        }
    } else { // Jika tidak ada ID, berarti tambah data baru
        $nama = $_POST['nm_user'];
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role = $_POST['role'];

        $query = "INSERT INTO tb_user (NamaUser, username, password, role) VALUES ('$nama', '$username', '$password', '$role')";
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['notif'] = "Data petugas berhasil ditambahkan.";
            $_SESSION['notif_type'] = "success";
        } else {
            $_SESSION['notif'] = "Gagal menambahkan data.";
            $_SESSION['notif_type'] = "error";
        }
    }

    header("Location: kasir_data.php");
    exit();
}