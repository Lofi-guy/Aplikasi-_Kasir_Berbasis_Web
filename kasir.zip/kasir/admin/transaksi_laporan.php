<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php";

$tgl_awal = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : '';
$tgl_akhir = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : '';

$query = "SELECT p.PenjualanID, p.TanggalPenjualan, pl.NamaPelanggan, u.username AS NamaPetugas, p.TotalHarga 
          FROM tb_penjualan p 
          JOIN tb_pelanggan pl ON p.PelangganID = pl.PelangganID
          JOIN tb_user u ON p.UserID = u.UserID";

if ($tgl_awal && $tgl_akhir) {
    $query .= " WHERE p.TanggalPenjualan BETWEEN '$tgl_awal' AND '$tgl_akhir'";
}

$query .= " ORDER BY p.TanggalPenjualan DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Filter Tanggal</h3>
                    </div>
                    <div class="box-body">
                        <form method="GET">
                            <div class="form-group">
                                <label>Tanggal Awal</label>
                                <input type="date" class="form-control" name="tgl_awal" value="<?= $tgl_awal; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tanggal Akhir</label>
                                <input type="date" class="form-control" name="tgl_akhir" value="<?= $tgl_akhir; ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Laporan Transaksi</h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>NOMOR TRANSAKSI</th>
                                    <th>TANGGAL PENJUALAN</th>
                                    <th>NAMA PELANGGAN</th>
                                    <th>NAMA PETUGAS</th>
                                    <th>TOTAL</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; while ($row = mysqli_fetch_array($result)) { ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['PenjualanID']; ?></td>
                                        <td><?= $row['TanggalPenjualan']; ?></td>
                                        <td><?= $row['NamaPelanggan']; ?></td>
                                        <td><?= $row['NamaPetugas']; ?></td>
                                        <td>Rp. <?= number_format($row['TotalHarga'], 0, ',', '.'); ?>,-</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include "footer.php"; ?>
