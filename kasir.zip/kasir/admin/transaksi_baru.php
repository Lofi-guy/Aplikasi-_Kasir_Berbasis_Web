<?php
session_start();
include "../config/koneksi.php";

// Generate ID transaksi
$tanggal = date('ymd');
$query = "SELECT MAX(PenjualanID) AS PenjualanID FROM tb_penjualan WHERE PenjualanID LIKE '$tanggal%'";
$result = mysqli_query($koneksi, $query);
$row = mysqli_fetch_array($result);

$urutan = 1;
if ($row['PenjualanID']) {
    $urutan = (int) substr($row['PenjualanID'], -4) + 1;
}

$kode_penjualan = $tanggal . sprintf("%04d", $urutan);

// Masukkan ke tb_penjualan (data awal kosong)
$user_id = $_SESSION['user_id']; // Pastikan session user ada
$query_penjualan = "INSERT INTO tb_penjualan (PenjualanID, TanggalPenjualan, UserID, TotalHarga) VALUES ('$kode_penjualan', NOW(), '$user_id', 0)";
mysqli_query($koneksi, $query_penjualan);

// Redirect ke transaksi.php dengan ID transaksi
header("Location: transaksi.php?no_trans=$kode_penjualan");
exit();
?>
