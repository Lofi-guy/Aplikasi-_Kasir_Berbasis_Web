<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}

include "header.php";
include "../config/koneksi.php";

// Cek apakah ada notifikasi di SESSION
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];
    $notif_type = $_SESSION['notif_type'];
    
    echo "<script>
            setTimeout(function() {
                Swal.fire({
                    title: 'Notifikasi',
                    text: '$notif',
                    icon: '$notif_type',
                    confirmButtonText: 'OK'
                });
            }, 500);
          </script>";
    
    unset($_SESSION['notif']);
    unset($_SESSION['notif_type']);
}

// Membuat kode transaksi hanya sekali
$dt_penjualan = mysqli_query($koneksi, "SELECT max(PenjualanID) as PenjualanID FROM tb_penjualan");
$penjualan = mysqli_fetch_array($dt_penjualan);
$kode_penjualan = $penjualan['PenjualanID'];
$urutan = (int) substr($kode_penjualan, -4, 4);
$urutan++;
$huruf = date('ymd');
$kodeBarang = $huruf . sprintf("%04s", $urutan);
?>

<div class="content-wrapper">
    <section class="content-header">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambah-transaksi">
            <i class="glyphicon glyphicon-plus"></i> Tambah
        </button>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>NO</th>
                                <th>NAMA BARANG</th>
                                <th>JUMLAH</th>
                                <th>SUBTOTAL</th>
                                <th>OPSI</th>
                            </thead>
                            <tbody>
                                <?php
                                $dt_penjualan = mysqli_query($koneksi, 
                                "SELECT tb_detail_penjualan.DetailID, tb_produk.NamaProduk, tb_detail_penjualan.JumlahProduk, tb_detail_penjualan.SubTotal 
                                FROM tb_detail_penjualan 
                                INNER JOIN tb_produk ON tb_produk.ProdukID = tb_detail_penjualan.ProdukID"
                            );
                            

                                $no = 1;
                                while ($penjualan = mysqli_fetch_array($dt_penjualan)) { 
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $penjualan['NamaProduk']; ?></td>
                                        <td><?= $penjualan['JumlahProduk']; ?></td>
                                        <td><?= isset($penjualan['SubTotal']) ? "Rp. " . number_format($penjualan['SubTotal'], 0, ',', '.') . ",-" : "Rp. 0"; ?>
                                    </td>
                                        <td>
    <a href="transaksi_detail_hapus.php?DetailID=<?= urlencode($penjualan['DetailID']); ?>" 
       onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')"
       class="btn btn-danger btn-sm">
       Hapus
    </a>
</td>




                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <?php 
                                    // Mengambil total belanja
                                    $sub_total_belanja = mysqli_query($koneksi, "SELECT SUM(SubTotal) AS Sub_Total FROM tb_detail_penjualan");

                                    $total_belanja = mysqli_fetch_array($sub_total_belanja);
                                    $total = $total_belanja['Sub_Total'] ?? 0;
                                    ?>
                                    <td colspan="3">Total Belanja</td>
                                    <td colspan="2"><strong><?= "Rp " . number_format($total, 0, ',', '.') . ",-" ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <form action="transaksi_proses.php" method="POST">
    <div class="col-md-3">
        <div class="box box-primary">
            <div class="box-body">

                <input type="hidden" class="form-control" name="produk" value="1">
                <input type="hidden" class="form-control" name="jumlah" value="1">
                <input type="hidden" class="form-control" name="subtotal" value="10000">

                <div class="form-group">
                    <label>Tanggal Pembelian</label>
                    <input type="date" class="form-control" name="tanggal" value="<?= date('Y-m-d') ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Nomor Transaksi</label>
                    <input type="text" class="form-control" name="no_trans" value="<?= $kodeBarang; ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Data Kasir</label>
                    <?php
                    // Mengambil data user yang sedang login
                    $username = $_SESSION['username'];
                    $dt_user = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE Username = '$username'");
                    $user = mysqli_fetch_array($dt_user);
                    ?>
                    <input type="hidden" class="form-control" name="nm_user" value="<?= $user['UserID'] ?>">
                    <input type="text" class="form-control" value="<?= $user['NamaUser'] ?>" readonly>
                </div>

                <div class="form-group">
                    <label for="pelanggan">Pilih Pelanggan</label>
                    <select name="pelanggan" id="pelanggan" class="form-control" required>
                        <option value="">-- Pilih Pelanggan --</option>
                        <?php
                        $dt_pelanggan = mysqli_query($koneksi, "SELECT * FROM tb_pelanggan");
                        while ($pelanggan = mysqli_fetch_array($dt_pelanggan)) {
                        ?>
                            <option value="<?= $pelanggan['PelangganID'] ?>"><?= $pelanggan['NamaPelanggan'] ?></option>
                        <?php } ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-success pull-right">Simpan</button>
            </div>
        </div>
    </div>
</form>


        </div>
    </section>
</div>

<div class="modal fade" id="tambah-transaksi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Tambah Data Barang</h4>
            </div>

            <form action="transaksi_detail_proses.php" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nomor Transaksi</label>
                        <input type="text" class="form-control" name="no_trans" value="<?= $kodeBarang; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>Pilih Barang</label>
                        <select name="produk" class="form-control" required>
                            <option value="1">-- Pilih Barang --</option>
                            <?php 
                            $dt_produk = mysqli_query($koneksi, "SELECT * FROM tb_produk");
                            while ($produk = mysqli_fetch_array($dt_produk)) {
                                echo '<option value="'.$produk['ProdukID'].'">'.$produk['NamaProduk'].' (Stok: '.$produk['Stok'].')</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah</label>
                        <input type="number" class="form-control" name="jumlah" placeholder="Jumlah" value="2" required>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "footer.php"; ?> 