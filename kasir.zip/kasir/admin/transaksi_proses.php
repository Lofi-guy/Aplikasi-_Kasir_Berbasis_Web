<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit();
}


include "../config/koneksi.php";

// Proses simpan transaksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal = $_POST['tanggal'];
    $no_trans = $_POST['no_trans'];
    $user_id = $_POST['nm_user'];
    $pelanggan_id = $_POST['pelanggan'];

    // Ambil total belanja
    $result = mysqli_query($koneksi, "SELECT SUM(SubTotal) AS total FROM tb_detail_penjualan");
    $total = mysqli_fetch_array($result)['total'] ?? 0;

    // Simpan ke tb_penjualan
    $query_penjualan = "INSERT INTO tb_penjualan (PenjualanID, TanggalPenjualan, UserID, PelangganID, TotalHarga) VALUES ('$no_trans', '$tanggal', '$user_id', '$pelanggan_id', '$total')";
    $simpan_penjualan = mysqli_query($koneksi, $query_penjualan);

    if ($simpan_penjualan) {
        // Kurangi stok di tb_produk dan hapus detail transaksi
        $dt_detail = mysqli_query($koneksi, "SELECT * FROM tb_detail_penjualan");
        while ($detail = mysqli_fetch_array($dt_detail)) {
            $produk_id = $detail['ProdukID'];
            $jumlah = $detail['JumlahProduk'];
            mysqli_query($koneksi, "UPDATE tb_produk SET Stok = Stok - $jumlah WHERE ProdukID = '$produk_id'");
        }

    

        $_SESSION['notif'] = 'Transaksi berhasil disimpan';
        $_SESSION['notif_type'] = 'success';
        header("Location: transaksi_data.php");
        exit();
    } else {
        $_SESSION['notif'] = 'Terjadi kesalahan saat menyimpan transaksi';
        $_SESSION['notif_type'] = 'error';
    }
}


?>
