<?php
include '../config/koneksi.php'; // Pastikan file koneksi database sudah ada

$PenjualanID = $_GET['id'];

// Ambil data penjualan dan pelanggan
$query_penjualan = mysqli_query($koneksi, "SELECT tb_penjualan.*, tb_pelanggan.NamaPelanggan FROM tb_penjualan INNER JOIN tb_pelanggan ON tb_penjualan.PelangganID = tb_pelanggan.PelangganID WHERE PenjualanID = '$PenjualanID'");
$data_penjualan = mysqli_fetch_assoc($query_penjualan);

// Ambil detail barang yang dibeli
$query_detail = mysqli_query($koneksi, "SELECT tb_detail_penjualan.*, tb_produk.NamaProduk FROM tb_detail_penjualan INNER JOIN tb_produk ON tb_detail_penjualan.ProdukID = tb_produk.ProdukID WHERE PenjualanID = '$PenjualanID'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Struk</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        .container { width: 300px; margin: auto; padding: 10px; border: 1px solid black; }
        h2 { margin: 5px 0; }
        p { margin: 2px 0; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; }
        table, th, td { border: 1px solid black; }
        th, td { padding: 5px; text-align: left; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .bold { font-weight: bold; }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <h2>TOKO MEXICO UTARA</h2>
        <p>Jl. Jendral Soedirman No. 175 Indramayu</p>
        <hr>
        <table>
            <tr>
                <td>No. Penjualan</td>
                <td>: <?php echo $data_penjualan['PenjualanID'] ?? '-'; ?></td>
            </tr>
            <tr>
                <td>Nama Pelanggan</td>
                <td>: <?php echo $data_penjualan['NamaPelanggan'] ?? 'Umum'; ?></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td>: <?php echo $data_penjualan['TanggalPenjualan'] ?? '-'; ?></td>
            </tr>
            <tr>
                <td>Total</td>
                <td class="bold">: Rp. <?php echo number_format($data_penjualan['TotalHarga'] ?? 0, 0, ',', '.'); ?>,-</td>
            </tr>
        </table>
        <h3>Detail Barang</h3>
        <table>
            <tr>
                <th class="text-center">No</th>
                <th>Nama Barang</th>
                <th class="text-center">Qty</th>
                <th class="text-right">Subtotal</th>
            </tr>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($query_detail)) { ?>
            <tr>
                <td class="text-center"><?php echo $no++; ?></td>
                <td><?php echo $row['NamaProduk']; ?></td>
                <td class="text-center"><?php echo $row['JumlahProduk']; ?></td>
                <td class="text-right">Rp. <?php echo number_format($row['Subtotal'], 0, ',', '.'); ?>,-</td>
            </tr>
            <?php } ?>
        </table>
        <hr>
        <p><em>*Terima kasih telah berbelanja di toko kami*</em></p>
    </div>
</body>
</html>
