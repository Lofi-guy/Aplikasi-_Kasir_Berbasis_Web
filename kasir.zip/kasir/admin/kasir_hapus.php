<?php
session_start();
include "../config/koneksi.php";

if (isset($_GET['UserID'])) {
    $UserID = $_GET['UserID'];

    // Eksekusi query hapus
    $hapus = mysqli_query($koneksi, "DELETE FROM tb_user WHERE UserID = '$UserID'");

    if ($hapus) {
        $_SESSION['notif'] = "Data petugas berhasil dihapus.";
        $_SESSION['notif_type'] = "success";
    } else {
        $_SESSION['notif'] = "Gagal menghapus data petugas: " . mysqli_error($koneksi);
        $_SESSION['notif_type'] = "error";
    }
}

// Redirect kembali ke halaman kasir_data.php
header("location: kasir_data.php");
exit();
?>
