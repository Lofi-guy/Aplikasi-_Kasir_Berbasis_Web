<?php
session_start();
include "../config/koneksi.php";

if (isset($_GET['ProdukID'])) {
    $ProdukID = $_GET['ProdukID'];

    // Eksekusi query hapus
    $hapus = mysqli_query($koneksi, "DELETE FROM tb_produk WHERE ProdukID = '$ProdukID'");

    if ($hapus) {
        $_SESSION['notif'] = "Data produk berhasil dihapus.";
        $_SESSION['notif_type'] = "success";
    } else {
        $_SESSION['notif'] = "Gagal menghapus data produk: " . mysqli_error($koneksi);
        $_SESSION['notif_type'] = "error";
    }
}

// Redirect kembali ke halaman produk_data.php
header("location: produk_data.php");
exit();
?>
